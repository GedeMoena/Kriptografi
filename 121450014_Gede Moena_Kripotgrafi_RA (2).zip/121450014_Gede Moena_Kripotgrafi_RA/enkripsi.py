def vigenere_standard(text, key, encrypt=True):
    key_length = len(key)
    key_as_int = [ord(i) - 65 for i in key.upper()]
    mode = 1 if encrypt else -1
    result = ''
    for i, char in enumerate(text.upper()):
        if char.isalpha():
            shift = (ord(char) - 65 + mode * key_as_int[i % key_length]) % 26
            result += chr(shift + 65)
        else:
            result += char
    return result

def vigenere_variant(text, key, encrypt=True):
    key_length = len(key)
    key_as_int = [ord(i) for i in key]
    mode = 1 if encrypt else -1
    result = ''
    for i, char in enumerate(text):
        shift = (ord(char) + mode * key_as_int[i % key_length]) % 256
        result += chr(shift)
    return result

def extended_vigenere(text, key, encrypt=True):
    key_length = len(key)
    key_as_int = [ord(i) for i in key]
    mode = 1 if encrypt else -1
    result = ''
    for i, char in enumerate(text):
        shift = (ord(char) + mode * key_as_int[i % key_length]) % 256
        result += chr(shift)
    return result

def playfair(text, key, encrypt=True):
    # Implementation of Playfair Cipher
    pass

def super_encryption(text, key):
    encrypted_vigenere = vigenere_standard(text, key)
    # Implement transposition cipher here
    return encrypted_vigenere

def save_to_file(filename, content):
    with open(filename, 'w') as file:
        file.write(content)

def main():
    text = input("Enter the text: ")
    key = input("Enter the key: ")
    choice = input("Enter the encryption method (a, b, c, d, e): ")

    if choice == 'a':
        ciphertext = vigenere_standard(text, key)
    elif choice == 'b':
        ciphertext = vigenere_variant(text, key)
    elif choice == 'c':
        ciphertext = extended_vigenere(text, key)
    elif choice == 'd':
        ciphertext = playfair(text, key)
    elif choice == 'e':
        ciphertext = super_encryption(text, key)
    else:
        print("Invalid choice!")
        return

    print("Ciphertext:")
    display_option = input("Choose display option:\n(a) As is\n(b) Without spaces\n(c) Grouped in 5-letter groups\nEnter option: ")

    if display_option.lower() == 'a':
        print(ciphertext)
    elif display_option.lower() == 'b':
        print(ciphertext.replace(" ", ""))
    elif display_option.lower() == 'c':
        grouped_ciphertext = ' '.join([ciphertext[i:i+5] for i in range(0, len(ciphertext), 5)])
        print(grouped_ciphertext)
    else:
        print("Invalid option!")

    # Save ciphertext to file
    save_option = input("Do you want to save the ciphertext to a file? (y/n): ")
    if save_option.lower() == 'y':
        filename = input("Enter filename: ")
        save_to_file(filename, ciphertext)
        print("Ciphertext saved to", filename)

if __name__ == "__main__":
    main()
