def vigenere_standard_decrypt(ciphertext, key):
    key_length = len(key)
    key_as_int = [ord(i) - 65 for i in key.upper()]
    result = ''
    for i, char in enumerate(ciphertext.upper()):
        if char.isalpha():
            shift = (ord(char) - 65 - key_as_int[i % key_length]) % 26
            result += chr(shift + 65)
        else:
            result += char
    return result

def vigenere_variant_decrypt(ciphertext, key):
    key_length = len(key)
    key_as_int = [ord(i) for i in key]
    result = ''
    for i, char in enumerate(ciphertext):
        shift = (ord(char) - key_as_int[i % key_length]) % 256
        result += chr(shift)
    return result

def extended_vigenere_decrypt(ciphertext, key):
    key_length = len(key)
    key_as_int = [ord(i) for i in key]
    result = ''
    for i, char in enumerate(ciphertext):
        shift = (ord(char) - key_as_int[i % key_length]) % 256
        result += chr(shift)
    return result

def playfair_decrypt(ciphertext, key):
    # Implementation of Playfair Cipher decryption
    pass

def super_decryption(ciphertext, key):
    decrypted_vigenere = vigenere_standard_decrypt(ciphertext, key)
    # Implement transposition cipher decryption here
    return decrypted_vigenere

def read_from_file(filename):
    with open(filename, 'r') as file:
        return file.read()

def main():
    # Baca ciphertext dari file
    filename = input("Enter filename to read ciphertext from: ")
    ciphertext = read_from_file(filename)

    # Input kunci
    key = input("Enter the key: ")

    # Dekripsi ciphertext
    choice = input("Enter the encryption method (a, b, c, d, e): ")

    if choice == 'a':
        plaintext = vigenere_standard_decrypt(ciphertext, key)
    elif choice == 'b':
        plaintext = vigenere_variant_decrypt(ciphertext, key)
    elif choice == 'c':
        plaintext = extended_vigenere_decrypt(ciphertext, key)
    elif choice == 'd':
        plaintext = playfair_decrypt(ciphertext, key)
    elif choice == 'e':
        plaintext = super_decryption(ciphertext, key)
    else:
        print("Invalid choice!")
        return

    print("Plaintext:", plaintext)

if __name__ == "__main__":
    main()

